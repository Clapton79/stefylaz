---
title: "Az esküvő helyszíne"
---

Az esküvőnket az **Európa Hajó** fedélzetén ünnepeljük, amely Budapestnél közlekedő rendezvényhajó a Dunán. A hajóról és szolgáltatásairól további információt az [Európa Hajó hivatalos weboldalán](https://europahajo.hu/en/home/) találtok.

A hajó végleges kikötési helye még megerősítésre vár (a Margit híd és a Szabadság híd közötti központi területen), de előre jelezni fogjuk.


### Az este programja

<dl class="event-schedule">
<dt>17:30</dt><dd>Érkezés és köszöntés.</dd>
<dt>17:45</dt><dd>Szertartás és spanyol falatok.</dd>
<dt>18:15</dt><dd>Hajózás és fotózás.</dd>
<dt>20:00</dt><dd>Vacsora</dd>
<dt>22:00</dt><dd>Élő zene és buli</dd>
<dt>23:30</dt><dd>Éjféli vacsora és tánc.</dd>
<dt>01:00</dt><dd>Búcsúzkodás.</dd>
<dt>01:30</dt><dd>Zárás – elhagyni a hajót! :D</dd>
</dl>

<img class="venue-photo" src="/images/EuropaHajo.png" alt="Az Európa Hajó a Dunán, Budapesten">