---
title: "Der Veranstaltungsort"
---

Wir feiern unsere Hochzeit an Bord der **Európa Hajó**, einem Veranstaltungsschiff auf der Donau in Budapest. Weitere Informationen zum Schiff und seiner Ausstattung findet ihr auf der [offiziellen Website der Európa Hajó](https://europahajo.hu/en/home/).

Der genaue Anleger wird noch bestätigt (im zentralen Bereich zwischen der Margaretenbrücke und der Freiheitsbrücke), aber wir geben ihn vorher bekannt.

### Ablauf des Abends

<dl class="event-schedule">
<dt>17:30</dt><dd>Ankunft und Begrüßung.</dd>
<dt>17:45</dt><dd>Zeremonie und spanische Häppchen.</dd>
<dt>18:15</dt><dd>Schifffahrt und Fotos.</dd>
<dt>20:00</dt><dd>Abendessen</dd>
<dt>22:00</dt><dd>Livemusik und Party</dd>
<dt>23:30</dt><dd>Mitternachtsimbiss und Tanz.</dd>
<dt>01:00</dt><dd>Verabschiedung.</dd>
<dt>01:30</dt><dd>Abschluss – Schiff verlassen! :D</dd>
</dl>

<img class="venue-photo" src="/images/EuropaHajo.png" alt="Die Európa Hajó auf der Donau in Budapest">