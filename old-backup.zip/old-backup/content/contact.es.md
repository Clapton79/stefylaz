---
title: "Contacto"
---

<section class="contact-section">
<h3>¿Alguna pregunta?</h3>
<p>¿Tienen alguna pregunta sobre la boda? Escríbannos a <a href="mailto:stef.laz.wedding@gmail.com">stef.laz.wedding@gmail.com</a>.</p>
</section>

<section class="contact-section">
<h3>Compartan sus fotos</h3>
<p>Si hacen fotos en el lugar de la celebración, nos encantará verlas. No las compartiremos; las guardaremos como recuerdo de este día tan especial.</p>
<span class="pending-link">El enlace para subir fotos estará disponible pronto</span>
</section>

<figure class="story-photo">
<img src="/images/StefLazCouch.jpg" alt="Stef y Laz descansando juntos en un sofá">
</figure>
